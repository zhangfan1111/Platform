// 城市json数据
var city_ = [
    {
        id: 1,
        name: '四川省',
        children: [
            {
                id: 11,
                name: '成都市',
                children: [
                    {
                        id: 111,
                        name: '锦江区'
                    },{
                        id: 112,
                        name: '武侯区'
                    },{
                        id: 113,
                        name: '青羊区'
                    },{
                        id: 114,
                        name: '金牛区'
                    },{
                        id: 115,
                        name: '成华区'
                    }
                ]
            },{
                id: 12,
                name: '广安市',
                children: [
                    {
                        id: 121,
                        name: '广安区'
                    },{
                        id: 122,
                        name: '前锋区'
                    },{
                        id: 123,
                        name: '武胜县'
                    },{
                        id: 124,
                        name: '华蓥'
                    },{
                        id: 125,
                        name: '邻水'
                    }
                ]
            },{
                id: 13,
                name: '绵阳市',
                children: [
                    {
                        id: 131,
                        name: '培城区'
                    },{
                        id: 132,
                        name: '游仙区'
                    },{
                        id: 133,
                        name: '高新区'
                    },{
                        id: 134,
                        name: '经开区'
                    },{
                        id: 135,
                        name: '科创园区'
                    }
                ]
            },{
                id: 14,
                name: '乐山市',
                children: [
                    {
                        id: 141,
                        name: '市中区'
                    },{
                        id: 142,
                        name: '沙湾区'
                    },{
                        id: 143,
                        name: '五通桥区'
                    },{
                        id: 144,
                        name: '金口河区'
                    },{
                        id: 145,
                        name: '井研县'
                    }
                ]
            },{
                id: 15,
                name: '南充市',
                children: [
                    {
                        id: 151,
                        name: '顺庆区'
                    },{
                        id: 152,
                        name: '高坪区'
                    },{
                        id: 153,
                        name: '嘉陵区'
                    },{
                        id: 154,
                        name: '仪陇县'
                    },{
                        id: 155,
                        name: '营山县'
                    }
                ]
            }
        ]
    },{
        id: 2,
        name: '广东省',
        children: [
            {
                id: 21,
                name: '广州市',
                children: [
                    {
                        id: 211,
                        name: '越秀区'
                    },{
                        id: 212,
                        name: '白云区'
                    },{
                        id: 213,
                        name: '天河区'
                    },{
                        id: 214,
                        name: '荔湾区'
                    },{
                        id: 215,
                        name: '海珠区'
                    }
                ]
            },{
                id: 22,
                name: '佛山市',
                children: [
                    {
                        id: 221,
                        name: '禅城区'
                    },{
                        id: 222,
                        name: '南海区'
                    },{
                        id: 223,
                        name: '顺德区'
                    },{
                        id: 224,
                        name: '三水区'
                    },{
                        id: 225,
                        name: '高明区'
                    }
                ]
            },{
                id: 23,
                name: '汕头市',
                children: [
                    {
                        id: 231,
                        name: '龙湖区'
                    },{
                        id: 232,
                        name: '金平区'
                    },{
                        id: 233,
                        name: '濠江区'
                    },{
                        id: 234,
                        name: '潮阳区'
                    },{
                        id: 235,
                        name: '潮南区'
                    }
                ]
            },{
                id: 24,
                name: '深圳市',
                children: [
                    {
                        id: 241,
                        name: '罗湖区'
                    },{
                        id: 242,
                        name: '福田区'
                    },{
                        id: 243,
                        name: '盐田区'
                    },{
                        id: 244,
                        name: '南山区'
                    },{
                        id: 245,
                        name: '宝安区'
                    }
                ]
            },{
                id: 25,
                name: '珠海市',
                children: [
                    {
                        id: 251,
                        name: '香洲区'
                    },{
                        id: 252,
                        name: '斗门区'
                    },{
                        id: 253,
                        name: '金湾区'
                    },{
                        id: 254,
                        name: '金鼎'
                    },{
                        id: 255,
                        name: '前山'
                    }
                ]
            }
        ]
    },{
        id: 3,
        name: '河北省',
        children: [
            {
                id: 31,
                name: '石家庄市',
                children: [
                    {
                        id: 311,
                        name: '长安区'
                    },{
                        id: 312,
                        name: '桥东区'
                    },{
                        id: 313,
                        name: '桥西区'
                    },{
                        id: 314,
                        name: '新华区'
                    },{
                        id: 315,
                        name: '裕华区'
                    }
                ]
            },{
                id: 32,
                name: '唐山市',
                children: [
                    {
                        id: 321,
                        name: '路北区'
                    },{
                        id: 322,
                        name: '路南区'
                    },{
                        id: 323,
                        name: '丰南区'
                    },{
                        id: 324,
                        name: '开平区'
                    },{
                        id: 325,
                        name: '丰润区'
                    }
                ]
            },{
                id: 33,
                name: '秦皇岛',
                children: [
                    {
                        id: 331,
                        name: '海港区'
                    },{
                        id: 332,
                        name: '北戴河区'
                    },{
                        id: 333,
                        name: '山海关区'
                    },{
                        id: 334,
                        name: '抚宁县'
                    },{
                        id: 335,
                        name: '昌黎县'
                    }
                ]
            },{
                id: 34,
                name: '邯郸市',
                children: [
                    {
                        id: 341,
                        name: '丛台区'
                    },{
                        id: 342,
                        name: '邯山区'
                    },{
                        id: 343,
                        name: '复兴区'
                    },{
                        id: 344,
                        name: '峰峰矿区'
                    },{
                        id: 345,
                        name: '邯郸县'
                    }
                ]
            },{
                id: 35,
                name: '邢台市',
                children: [
                    {
                        id: 351,
                        name: '桥东区'
                    },{
                        id: 352,
                        name: '桥西区'
                    },{
                        id: 353,
                        name: '高开区'
                    },{
                        id: 354,
                        name: '大曹庄管理区'
                    },{
                        id: 355,
                        name: '邢台县'
                    }
                ]
            }
        ]
    },{
        id: 4,
        name: '湖北省',
        children: [
            {
                id: 41,
                name: '武汉市',
                children: [
                    {
                        id: 411,
                        name: '武昌区'
                    },{
                        id: 412,
                        name: '汉口区'
                    },{
                        id: 413,
                        name: '汉阳区'
                    },{
                        id: 414,
                        name: '青山区'
                    },{
                        id: 415,
                        name: '洪山区'
                    }
                ]
            },{
                id: 42,
                name: '黄石市',
                children: [
                    {
                        id: 421,
                        name: '黄石港区'
                    },{
                        id: 422,
                        name: '西塞山区'
                    },{
                        id: 423,
                        name: '下陆区'
                    },{
                        id: 424,
                        name: '大冶市'
                    },{
                        id: 425,
                        name: '阳新区'
                    }
                ]
            },{
                id: 43,
                name: '荆州市',
                children: [
                    {
                        id: 431,
                        name: '荆州区'
                    },{
                        id: 432,
                        name: '沙市区'
                    },{
                        id: 433,
                        name: '石首市'
                    },{
                        id: 434,
                        name: '松滋市'
                    },{
                        id: 435,
                        name: '洪湖市'
                    }
                ]
            },{
                id: 44,
                name: '宜昌市',
                children: [
                    {
                        id: 441,
                        name: '三市'
                    },{
                        id: 442,
                        name: '五城区'
                    },{
                        id: 443,
                        name: '归县'
                    },{
                        id: 444,
                        name: '远安县'
                    },{
                        id: 445,
                        name: '兴山县'
                    }
                ]
            },{
                id: 45,
                name: '襄樊市',
                children: [
                    {
                        id: 451,
                        name: '襄城区'
                    },{
                        id: 452,
                        name: '高新区'
                    },{
                        id: 453,
                        name: '襄州区'
                    },{
                        id: 454,
                        name: '樊城区'
                    },{
                        id: 455,
                        name: '枣阳市'
                    }
                ]
            }
        ]
    },{
        id: 5,
        name: '北京',
        children: [
            {
                id: 51,
                name: '东城区'
            },{
                id: 52,
                name: '西城区'
            },{
                id: 53,
                name: '朝阳区'
            },{
                id: 54,
                name: '丰台区'
            },{
                id: 55,
                name: '石景山区'
            }
        ]
    }
]



$(function(){

    // 三级联动
    $.each(city_,function(i,o){
        //遍历第一层添加到第一个select里面去
        $("#province").append('<option value="'+o.id+'">'+o.name+'</option>');
    })

    //当第一个select变化的时候添加第二个
    $("#province").change(function(){
        //当地一个变化的时候取消掉后两个的disabled属性并取消掉背景颜色
        $("#city").attr("disabled",false).removeClass("disabled_");
        $("#Area").attr("disabled",false).removeClass("disabled_");

        $("#city").empty();//清空原来的数据（下同）
        $("#Area").empty();
        var val1_ = $(this).val();//获得当前选中的id
        $.each(city_,function(i,o){//遍历当前选中的子数组
            if(val1_ == o.id){//找到当前选中的对象
                var obj_ = o.children;//找到第一个选中的下面的子数组
                var obj2_ = obj_[0].children;//找到第一个选中的默认选中第二个的子数组，便于给第三个添加数据
                if(!obj2_){//判断是否有第三级城市（如北京这样的）
                    $("#Area").hide();//没有就隐藏第三个选择框
                } else {
                    $("#Area").show();//有就显示第三个选择框
                }
                $.each(obj_,function(n,d){//遍历第一个选中对应的子数组
                    $("#city").append('<option value="'+d.id+'">'+d.name+'</option>');//为第二个select添加数据
                })
                $.each(obj2_,function(m,s){//遍历第二个默认选中对应的子数组
                    $("#Area").append('<option value="'+s.id+'">'+s.name+'</option>');//为第三个select添加数据
                })
            }
        })
    })

    //当第二个select变化的时候添加第三个
    $("#city").change(function(){
        $("#Area").empty();//清空原来的数据
        var val1 = $("#province").val()//获得第一个select的id
        var val2_ = $(this).val();//获得第二个当前选中的id
        $.each(city_,function(i,o){//遍历当前选中的子数组
            if(val1 == o.id){//找到第1个选中对应的对象
                var obj_ = o.children;//找到第1个选中对象下的子数组
                $.each(obj_,function(n,d){//遍历第二级循环数组
                    if(val2_ == d.id){//找到选中的对象
                        var objc_ = d.children;//找到第2个选中对象下的子数组
                        $.each(objc_,function(m,s){
                            $("#Area").append('<option value="'+s.id+'">'+s.name+'</option>');//为第三个添加数据
                        })
                    }
                })
            }
        })
    })

})



