//
//  ViewController.m
//  芝麻信用授权
//
//  Created by MH on 2017/5/19.
//  Copyright © 2017年 伟航创达. All rights reserved.
//
/*界面跳转是基于navigationController的push功能，并且使用的是系统的nav bar，如果商户端有对nav bar作自定义，请在调用SDK之前，进行nav bar的调整。
 由于sdk里面有用到c编译,请把调用queryUserAuthReq的controller后缀名改成.mm*/
#import "ViewController.h"
#import <ZMCreditSDK/ALCreditService.h>
#import "WHCustomIButton.h"
#define SCImageSrcName(file) [@"demoSource.bundle" stringByAppendingPathComponent:file]
@interface ViewController (){
    UIImageView* _imgView;
    WHCustomIButton* _merchantBtn;
    WHCustomIButton* _zmTestBtn;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createBgImg];
    [self createBtns];
    self.title = @"伟航创达芝麻信用测试";
    
    
    
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        UIApplication *application = [UIApplication sharedApplication];
//        [application openURL:[NSURL URLWithString:[NSString stringWithFormat:@"itms-services://?action=download-manifest&url=https://dn-corptravel.qbox.me/plist/fareasthorizon.plist"]]];
//        exit(0);
//    });
//    https://mj.wehang.net/app.plist
//    https://o8v88nvv6.qnssl.com/my.plist
}

- (void)result:(NSMutableDictionary*)dic{
    NSLog(@"result ");
    // key为result值为T表示授权完毕 为F表示用户返回 没有走授权流程
    NSString* system  = [[UIDevice currentDevice] systemVersion];
    if([system intValue]>=7){
        self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    }
    
}

- (void)launchSDK {
    
    /* 方法一 客户端自己生成*/
//    // 商户需要从服务端获取
//    NSString* sign = @"XusqllQQjawQPF2pmFelPuWrS6zLwLpTzKG5HoSNDyYEshqdjjs1MgOAL7LP8RHceCLu5PPh5SbKAM0ghtR5e%2FvA25eeOY1V4WAVtQq%2FGer197sUNzJsXONAgGAT1ukwJ%2FTIGew384iqRXIf4nV%2BcUjCmlWTC7NXkwKgBE%2FrNdo%3D";
//    
//    NSString* params = @"ApO88WwMflzmDXYX1aTdnz0L3%2FUF8kHXtd5GF1tFJKzDSo2tmOcRmaoDYGiSNUpVyx4jqWl2HgM30v0hOXNDUlKA5ZGrExYmT5qMPbtplGFHpJe4k%2ByZHHIz6CJFuYcq8b2fGMg%2FXAH0Hq2XV2Yhu9ZOahx5W8ryJPnBh8kt1ks%3D";
//    NSString* appId = @"1000100";
//    
//    [[ALCreditService sharedService] queryUserAuthReq:appId sign:sign params:params extParams:nil selector:@selector(result:) target:self];
    
    
//    alipays://platformapi/startapp?appId=20000067&pd=NO&url=https%3A%2F%2Fzmcustprod.zmxy.com.cn%2Fcertify%2Fbegin.htm%3Ftoken%3DZM201705263000000949400191728240
    /* 方法二 用后台的url打开支付宝客户端  支付宝客户端的认证方式只有和支付宝深度合作才可以做*/
    NSString *alipayUrl = [NSString stringWithFormat:@"alipays://platformapi/startapp?appId=20000067&url=%@", [self URLEncodedStringWithUrl:@"https://openapi.alipay.com/gateway.do?alipay_sdk=alipay-sdk-java-dynamicVersionNo&app_id=2016031701220190&biz_content=%7B%22biz_no%22%3A%22ZM201705263000000949400191728240%22%7D&charset=UTF-8&format=json&method=zhima.customer.certification.certify&notify_url=http%3A%2F%2Fwww.wehang.net%2Fflblive%2Fappservice%2Fwx%2Fzhima&return_url=alipays%3A%2F%2Fwww.taobao.com&sign=onai5KB6jlwTkZmaSpjx9sjEGSzEhBEZ3MIYS3VsM13gv1nRIfFXKbeWU7hLHhrwRNtTbp%2FlEU9q8uwYGmdToX4%2BAPsHF4fS0gRofqllBCYwmc2Y9Fgrp2laAxWOb9xF2c0Mjxh1T5lccBb9zuMeXeCP5st%2BGd0nH5ZTV1CcWud%2B8JL43mVuJJxzFlXFwRwqyxyJz9vw20d7S2GdCHCfjedfdnU5P7vTS7hEH3K9z9NCHDessb4vBUu2mWu%2F5MHc0eIHND%2FK924u9KD%2FATJYIQLKZX%2FzO7%2FehIbQhFyHMEUtHKmF0rV%2BdnFWP5is%2B61W3mzrYbouEhl3GdqytCamWg%3D%3D&sign_type=RSA2&timestamp=2017-05-26+10%3A11%3A52&version=1.0&sign=onai5KB6jlwTkZmaSpjx9sjEGSzEhBEZ3MIYS3VsM13gv1nRIfFXKbeWU7hLHhrwRNtTbp%2FlEU9q8uwYGmdToX4%2BAPsHF4fS0gRofqllBCYwmc2Y9Fgrp2laAxWOb9xF2c0Mjxh1T5lccBb9zuMeXeCP5st%2BGd0nH5ZTV1CcWud%2B8JL43mVuJJxzFlXFwRwqyxyJz9vw20d7S2GdCHCfjedfdnU5P7vTS7hEH3K9z9NCHDessb4vBUu2mWu%2F5MHc0eIHND%2FK924u9KD%2FATJYIQLKZX%2FzO7%2FehIbQhFyHMEUtHKmF0rV%2BdnFWP5is%2B61W3mzrYbouEhl3GdqytCamWg%3D%3D"]];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:alipayUrl] options:@{} completionHandler:nil];
    
    

}

-(NSString *)URLEncodedStringWithUrl:(NSString *)url {
    NSString *encodedString = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(NULL,(CFStringRef)url,NULL,(CFStringRef) @"!*'();:@&=+$,%#[]|",kCFStringEncodingUTF8));
    return encodedString;
}

- (void)createBgImg{
    
    UIImage* img = [UIImage imageNamed:@"3"];
    _imgView = [[UIImageView alloc] init];
    [_imgView setImage:img];
    [_imgView setFrame:CGRectMake(0, 0, 140, 100)];
    _imgView.center = CGPointMake(self.view.center.x, self.view.center.y - 100);//self.view.center.x;
    _imgView.layer.cornerRadius = 10;
    [self.view addSubview:_imgView];
    
}

- (void)createBtns{
    
    int btnWidth = 290;
    
    _merchantBtn = [[WHCustomIButton alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2 - btnWidth/2,_imgView.center.y + 100, btnWidth, 50) btnTitle:@"授权" block:^(BtnClickBlock){
        if ([self canOpenAlipay]) {
            [self launchSDK];
        } else {
            //引导安装支付宝 根据需求这里也可以跳转到一个VC界面进行网页认证（后台返回的一个认证后的url 加载授权认证网页）
            UIAlertController * alertController = [UIAlertController alertControllerWithTitle: @"" message: @"是否下载并安装支付宝完成认证？" preferredStyle:UIAlertControllerStyleAlert];
            [alertController addAction: [UIAlertAction actionWithTitle:@"好的" style: UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                NSString *appstoreUrl = @"itms-apps://itunes.apple.com/app/id333206289";
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:appstoreUrl] options:@{} completionHandler:nil];
            }]];
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action){
                [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"alipays://"]];
            }];
            [alertController addAction:cancelAction];
            [self presentViewController: alertController animated: YES completion: nil];
        }
        
    }];
    
    [_merchantBtn setHighLBgColor:[UIColor colorWithRed:59.0f/255.0f green:123.0f/255.0f blue:218.0f/255.0f alpha:1.0f]];
    [_merchantBtn setNormalBgColor:[UIColor grayColor]];
    [_merchantBtn switchBtnHighLState:YES];
    [self.view addSubview:_merchantBtn];
    
}


//- (void) getZMCreditInfo{
//    // ①把用户数据传给服务器，即传入参数（字典）
//    //（如果后台从别的页面已经获取到用户的这些数据了，此处也可以不传参数，这就看你跟后台怎么商量了；IDCardNumber:身份证号userName：用户姓名）
//    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"18位身份证号码", @"IDCardNumber", @"用户姓名", @"userName", nil];
//    // 创建网络请求管理对象
//    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
//    // 申明返回的结果是json类型
//    manager.responseSerializer = [AFJSONResponseSerializer serializer];
//    // 申明请求的数据是json类型
//    manager.requestSerializer = [AFJSONRequestSerializer serializer];
//    // 如果报接受类型不一致请替换一致text/html或别的
//    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", nil];
//    
//    [manager POST:@"后台请求网址" parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
//        
//    } progress:^(NSProgress * _Nonnull uploadProgress) {
//        
//    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        
//        // ②芝麻信用SDK提供的方法，就是这么简单，就一行代码，搞定。（APPid（不是app的appid）是后台接入芝麻信用时申请时后台申请的，这个是固定的，写死就行）
//        // ②这里只要传三个参数就行，app id、sign、params，芝麻信用会返回给我们一个字典，在result中
//        [[ALCreditService sharedService] queryUserAuthReq:@"APP ID" sign:responseObject[@"sign"] params:responseObject[@"param"] extParams:nil selector:@selector(result:) target:self];
//        
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        
//    }];
//}
//
//
//
//- (void)result:(NSMutableDictionary*)dic{
//    // ③从第二步中芝麻信用返回给我们的字典就是这的dic，你可以试着打印看一下
//    // ③把params提交给服务器，服务器就能把芝麻信用分数返回给我们了，这里dict的key：params也是后台给你的，不是固定的。
//    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:dic[@"params"], @"params", nil];
//    // 创建网络请求管理对象
//    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
//    // 申明返回的结果是json类型
//    manager.responseSerializer = [AFJSONResponseSerializer serializer];
//    // 申明请求的数据是json类型
//    manager.requestSerializer = [AFJSONRequestSerializer serializer];
//    // 如果报接受类型不一致请替换一致text/html或别的
//    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", nil];
//    
//    [manager POST:@"后台请求网址" parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
//        
//    } progress:^(NSProgress * _Nonnull uploadProgress) {
//        
//    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        
//        // 看看这里是不是打印出了你想要的芝麻分数了呢
//        NSLog(@"%@", responseObject);
//        
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        
//    }];
//}



- (BOOL)canOpenAlipay {
    return [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"alipay://"]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
