//
//  WHCustomIButton.m
//  芝麻信用授权
//
//  Created by MH on 2017/5/19.
//  Copyright © 2017年 伟航创达. All rights reserved.
//

#import "WHCustomIButton.h"

@interface WHCustomIButton (){
    BOOL _isShowHighL;
    
    UIColor* _normalBgColor;
    UIColor* _normalBorderColor;
    
    UIColor* _touchDownBgColor;
    UIColor* _touchDownBorderColor;
    
    UIColor* _touchDownTitleColor;
    UIColor* _normalTitleColor;
    
    UIImage * _normalImage;
    UIImage * _touchDownImage;
    UIImageView *_imgView;
    
    BtnClickBlock _block;
}

@end

@implementation WHCustomIButton

- (id)initWithFrame:(CGRect)frame btnTitle:(NSString*)btnTitle block:(BtnClickBlock)block{
    self = [super initWithFrame:frame];
    if(self){
        // 设置变量默认值
        [self.layer setMasksToBounds:YES];
        [self.layer setCornerRadius:5];
        [self.layer setBorderWidth:1.0];
        
        [self setDefaultParamValue];
        
        // 设置title
        [self setTitle:btnTitle forState:UIControlStateNormal];
        self.titleLabel.textColor = _normalTitleColor;
        
        [self addTarget:self action:@selector(touchDown:) forControlEvents:UIControlEventTouchDown];
        [self addTarget:self action:@selector(touchUpInside:) forControlEvents:UIControlEventTouchUpInside];
        [self addTarget:self action:@selector(touchUpCancel:) forControlEvents:UIControlEventTouchDragExit];
        
        // 刚开始的状态是normal
        [self setBackgroundColor:_normalBgColor];
        [self.layer setBorderColor:_normalBorderColor.CGColor];
        _isShowHighL = NO;
        
        _block = block;
    }
    
    return self;
}

- (void)setDefaultParamValue{
    
    //设置默认值
    _normalBgColor     = [UIColor redColor];
    _normalBorderColor = NULL;//[UIColor ];
    
    _touchDownBgColor     = [UIColor colorWithRed:239.0/255.0 green:239.0/255.0 blue:239.0/255.0 alpha:1.0];
    _touchDownBorderColor = [UIColor colorWithRed:191.0/255.0 green:191.0/255.0 blue:191.0/255.0 alpha:1.0];
    
    _touchDownTitleColor  = [UIColor whiteColor];
    _normalTitleColor     = [UIColor grayColor];
    
}

- (UIImage*)imageWithColor:(UIColor *)color size:(CGSize)size{
    CGRect rect = CGRectMake(0, 0, size.width, size.height);
    
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

- (void)setHighLBgColor:(UIColor *)color{
    
    _touchDownBgColor = color;
}

- (void)setHighLBorderColor:(UIColor *)color{
    _touchDownBorderColor = color;
}

- (void)setNormalBgColor:(UIColor *)color{
    _normalBgColor = color;
}

- (void)setNormalBorderColor:(UIColor *)color{
    _normalBorderColor = color;
}

- (void)setTitle:(NSString *)title{
    [self setTitle:title forState:UIControlStateNormal];
    
}

- (void)setNormalTitleColor:(UIColor *)color{
    _normalTitleColor = color;
}

- (void)setHighLTitleColor:(UIColor *)color{
    _touchDownTitleColor = color;
}

- (void)setTitleFont:(UIFont *)font{
    self.titleLabel.font = font;
}

- (void)setBtnImage:(UIImage *)normalImg highImg:(UIImage *)highImg{
    
    _normalImage = normalImg;
    _touchDownImage = highImg;
    
    if(!_imgView){
        _imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0,0, self.frame.size.width, self.frame.size.height)];
        
        [self addSubview:_imgView];
    }
    
}

- (void)drawRect:(CGRect)rect{
    [super drawRect:rect];
    
    [self switchBtnHighLState:_isShowHighL];
}

- (void)setInteraction:(BOOL)isEnabled
{
    self.userInteractionEnabled = isEnabled;
    //  btn背景是hight状态（表示已经按下了，不能再按）
    [self switchBtnHighLState:!isEnabled];
}

- (void)switchBtnHighLState:(BOOL)isBtnHighL
{
    _isShowHighL = isBtnHighL;
    
    // 图片btn
    if(_imgView){
        if(_isShowHighL){
            [_imgView setImage:_touchDownImage];
        }else{
            [_imgView setImage:_normalImage];
        }
        return;
    }
    
    // 自绘制btn
    if(_isShowHighL){
        [self setBackgroundColor:_touchDownBgColor];
        [self.layer setBorderColor:_touchDownBgColor.CGColor];
        self.titleLabel.textColor = _touchDownTitleColor;
        //_label.textColor = _highLTitleColor;
        
    }else{
        [self setBackgroundColor:_normalBgColor];
        [self.layer setBorderColor:_normalBorderColor.CGColor];
        self.titleLabel.textColor = _normalTitleColor;
        
    }
}

- (void)touchDown:(id)sender{
    
    [self switchBtnHighLState:!_isShowHighL];
    
}

- (void)touchUpInside:(id)sender
{
    [self switchBtnHighLState:!_isShowHighL];
    
    
    if(_block)
        _block(self);
}

- (void)touchUpCancel:(id)sender{
    [self switchBtnHighLState:!_isShowHighL];
    
}
@end
