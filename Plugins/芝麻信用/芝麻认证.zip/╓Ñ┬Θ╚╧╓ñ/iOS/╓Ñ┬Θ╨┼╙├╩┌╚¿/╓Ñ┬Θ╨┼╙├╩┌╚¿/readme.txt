//WH LTD ZhiMaCreditForIOS V1.0
—Created by MH 2017/5/19

------------------------------------
1. 向工程中导入SDK Framework文件

Build Phases -> Link Binary With Libraries 里导入库

ZMCreditSDK.framework

ZMDependUponSDK.framework

注意:如果商户引入支付宝钱包SDK,则不需要再引入ZMDependUponSDK.framework, 因为这样可以解决相同类库冲突的问题

2. 将资源bundle导入工程

H5Service.bundle

Poseidon.bundle

3. 导入其他依赖库

SDK中依赖了其他基础库来保证正常运行，请添加如下依赖库:

MobileCoreServices.framewrok，CFNetwork.framework，MessageUI.framework，EventKit.framework,AssetsLibrary.framework,CoreMotion.framework,Libz.dylib （Xcode 7 之后是libz.tbd）,SystemConfiguration.framework,CoreTelephony.framework


在判断是否安装支付宝时，需要在info.Plist文件中设置key为LSApplicationQueriesSchemes  值为alipayshare/alipay

------------------------------------
