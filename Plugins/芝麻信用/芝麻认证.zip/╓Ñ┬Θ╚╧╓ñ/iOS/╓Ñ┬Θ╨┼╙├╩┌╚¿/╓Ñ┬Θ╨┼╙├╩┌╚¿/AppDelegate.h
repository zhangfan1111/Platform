//
//  AppDelegate.h
//  芝麻信用授权
//
//  Created by MH on 2017/5/19.
//  Copyright © 2017年 伟航创达. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

