//
//  WHCustomIButton.h
//  芝麻信用授权
//
//  Created by MH on 2017/5/19.
//  Copyright © 2017年 伟航创达. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^BtnClickBlock)(id);
@interface WHCustomIButton : UIButton
- (id)initWithFrame:(CGRect)frame btnTitle:(NSString*)btnTitle block:(BtnClickBlock)block;

/**
 * 设置高亮背景色
 */
- (void)setHighLBgColor:(UIColor *)color;

/**
 * 设置高亮边框颜色
 */
- (void)setHighLBorderColor:(UIColor *)color;

/**
 * 设置正常背景色
 */
- (void)setNormalBgColor:(UIColor *)color;

/**
 * 设置正常边框颜色
 **/
- (void)setNormalBorderColor:(UIColor *)color;

/**
 * 切换btn 高亮状态
 * @param isBtnHighL false 按钮背景为Normal状态
 *                   true  按钮背景是hightL状态，表示按下
 */
- (void)switchBtnHighLState:(BOOL)isBtnHighL;

/**
 * 设置btn title
 * @param title btn的提示文案
 **/
- (void)setTitle:(NSString *)title;

/**
 * 设置正常的title 颜色
 **/
- (void)setNormalTitleColor:(UIColor *)color;


/**
 * 设置高亮的title颜色
 **/
- (void)setHighLTitleColor:(UIColor *)color;

/**
 * 设置是否响应事件
 * @param isEnabled true 按钮可以响应点击事件 btn背景是Normal状态
 *                  false 按钮不响应点击     btn背景是hight状态（表示已经按下了，不能再按）
 */
- (void)setInteraction:(BOOL)isEnabled;

/**
 * 设置文字字体
 */
- (void)setTitleFont:(UIFont *)font;

/**
 * 设置成图片按钮
 */
- (void)setBtnImage:(UIImage *)normalImg highImg:(UIImage *)highImg;
@end
